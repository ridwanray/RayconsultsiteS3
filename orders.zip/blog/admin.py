from django.contrib import admin
from .models import Blog
#from .models import Sport, Health, Education, Travel, Programming, Hardware, Networking, Politics, Business, Nutrition, Agriculture, lifestyle, Software

admin.site.register(Blog)
"""admin.site.register(Sport)
admin.site.register(Health)
admin.site.register(Education)
admin.site.register(Travel)
admin.site.register(Programming)
admin.site.register(Hardware)
admin.site.register(Networking)
admin.site.register(Politics)
admin.site.register(Business)
admin.site.register(Nutrition)
admin.site.register(Agriculture)
admin.site.register(lifestyle)
admin.site.register(Software)"""
